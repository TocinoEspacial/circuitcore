from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Cotizacion, CotizacionItem

from django import forms
from .models import Cotizacion, CotizacionItem
from django.core.validators import MinValueValidator
from decimal import Decimal

class CotizacionForm(forms.ModelForm):
    class Meta:
        model = Cotizacion
        fields = ['aplica_iva', 'descuento', 'observaciones', 'contacto', 'ciudad', 'tipo_pago']
        widgets = {
            'contacto': forms.TextInput(attrs={'class': 'form-control'}),
            'ciudad': forms.Select(attrs={'class': 'form-select'}),
            'tipo_pago': forms.Select(attrs={'class': 'form-select'}),
            'observaciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }
        labels = {
            'aplica_iva': 'Aplicar IVA (19%)',
            'descuento': 'Porcentaje de descuento',
            'observaciones': 'Observaciones adicionales',
            'contacto': 'Persona de contacto',
            'ciudad': 'Ciudad del proyecto',
            'tipo_pago': 'Método de pago',
        }

    aplica_iva = forms.BooleanField(
        label="Aplicar IVA (19%)",
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'},))
    
    descuento = forms.DecimalField(
        label="Porcentaje de descuento",
        required=False,
        initial=0,
        max_digits=5,
        decimal_places=2,
        validators=[MinValueValidator(0)],
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'step': '0.01',
            'min': '0',
            'max': '100'
        }),
        help_text="Ingrese un valor entre 0 y 100%"
    )

class CotizacionItemForm(forms.ModelForm):
    class Meta:
        model = CotizacionItem
        fields = ['descripcion', 'cantidad', 'unidad_medida', 'valor_unidad', 'notas']
        widgets = {
            'descripcion': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Descripción del trabajo/material'
            }),
            'cantidad': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0.01'
            }),
            'unidad_medida': forms.Select(attrs={'class': 'form-select'}),
            'valor_unidad': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.01',
                'min': '0'
            }),
            'notas': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Notas adicionales'
            })
        }
        labels = {
            'descripcion': 'Descripción',
            'cantidad': 'Cantidad',
            'unidad_medida': 'Unidad',
            'valor_unidad': 'Valor Unitario',
            'notas': 'Notas'
        }

# Formulario de ítems para el ingeniero (con campos calculables)
class CotizacionItemIngenieroForm(forms.ModelForm):
    class Meta:
        model = CotizacionItem
        fields = ['descripcion', 'cantidad', 'valor_unidad']
        widgets = {
            'descripcion': forms.TextInput(attrs={'readonly': 'readonly'}),
            'cantidad': forms.NumberInput(attrs={'readonly': 'readonly'}),
        }

# Formulario del ingeniero para completar una cotización
class CotizacionRevisarForm(forms.ModelForm):
    class Meta:
        model = Cotizacion
        fields = ['tipo_pago', 'descuento', 'aplica_iva']

# Registro de nuevos usuarios
class CustomUserCreationForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=True, help_text='Requerido.')
    last_name = forms.CharField(max_length=30, required=True, help_text='Requerido.')
    email = forms.EmailField(max_length=254, required=True, help_text='Requerido. Usa una dirección válida.')

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')
        from django import forms
from .models import PerfilUsuario

class PerfilForm(forms.ModelForm):
    class Meta:
        model = PerfilUsuario
        fields = ['avatar', 'rol'] 

from django import forms
from .models import PerfilUsuario
from django.contrib.auth.models import User

class PerfilForm(forms.ModelForm):
    class Meta:
        model = PerfilUsuario
        fields = ['avatar', 'telefono', 'direccion']

class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']
